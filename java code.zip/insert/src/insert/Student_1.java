/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insert;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author user
 */
@Entity
@Table(name = "student", catalog = "prak01", schema = "public")
@NamedQueries({
    @NamedQuery(name = "Student_1.findAll", query = "SELECT s FROM Student_1 s")
    , @NamedQuery(name = "Student_1.findByMatricno", query = "SELECT s FROM Student_1 s WHERE s.matricno = :matricno")
    , @NamedQuery(name = "Student_1.findByStudentname", query = "SELECT s FROM Student_1 s WHERE s.studentname = :studentname")
    , @NamedQuery(name = "Student_1.findBySemester", query = "SELECT s FROM Student_1 s WHERE s.semester = :semester")
    , @NamedQuery(name = "Student_1.findBySesion", query = "SELECT s FROM Student_1 s WHERE s.sesion = :sesion")
    , @NamedQuery(name = "Student_1.findByOrganization", query = "SELECT s FROM Student_1 s WHERE s.organization = :organization")})
public class Student_1 implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "matricno")
    private Integer matricno;
    @Column(name = "studentname")
    private String studentname;
    @Column(name = "semester")
    private String semester;
    @Column(name = "sesion")
    private String sesion;
    @Column(name = "organization")
    private String organization;

    public Student_1() {
    }

    public Student_1(Integer matricno) {
        this.matricno = matricno;
    }

    public Integer getMatricno() {
        return matricno;
    }

    public void setMatricno(Integer matricno) {
        Integer oldMatricno = this.matricno;
        this.matricno = matricno;
        changeSupport.firePropertyChange("matricno", oldMatricno, matricno);
    }

    public String getStudentname() {
        return studentname;
    }

    public void setStudentname(String studentname) {
        String oldStudentname = this.studentname;
        this.studentname = studentname;
        changeSupport.firePropertyChange("studentname", oldStudentname, studentname);
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        String oldSemester = this.semester;
        this.semester = semester;
        changeSupport.firePropertyChange("semester", oldSemester, semester);
    }

    public String getSesion() {
        return sesion;
    }

    public void setSesion(String sesion) {
        String oldSesion = this.sesion;
        this.sesion = sesion;
        changeSupport.firePropertyChange("sesion", oldSesion, sesion);
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        String oldOrganization = this.organization;
        this.organization = organization;
        changeSupport.firePropertyChange("organization", oldOrganization, organization);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (matricno != null ? matricno.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Student_1)) {
            return false;
        }
        Student_1 other = (Student_1) object;
        if ((this.matricno == null && other.matricno != null) || (this.matricno != null && !this.matricno.equals(other.matricno))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "insert.Student_1[ matricno=" + matricno + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
